package com.niit.collaboration.model;

import java.sql.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Forum {
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String f_category;
	private String f_title;
	private String f_content;
	private Date f_date;
	private String f_User;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getF_category() {
		return f_category;
	}
	public void setF_category(String f_category) {
		this.f_category = f_category;
	}
	public String getF_title() {
		return f_title;
	}
	public void setF_title(String f_title) {
		this.f_title = f_title;
	}
	public String getF_content() {
		return f_content;
	}
	public void setF_content(String f_content) {
		this.f_content = f_content;
	}
	public Date getF_date() {
		return f_date;
	}
	public void setF_date(Date f_date) {
		this.f_date = f_date;
	}
	public String getF_User() {
		return f_User;
	}
	public void setF_User(String f_User) {
		this.f_User = f_User;
	}
	
	
	
}
