package com.niit.collaboration.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Chat {
	
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private String id;
	private String c_name;
	private String c_massages;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public String getC_massages() {
		return c_massages;
	}
	public void setC_massages(String c_massages) {
		this.c_massages = c_massages;
	}
	
	
	
}
