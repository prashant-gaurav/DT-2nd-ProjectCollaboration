package com.niit.collaboration.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.User;

@Repository("categoryDAO")
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	private SessionFactory sessionFactory;


	public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<User> list() {
		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) sessionFactory.getCurrentSession()
				.createCriteria(User.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
		}

		@Transactional
		public boolean saveOrUpdate (User user) {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
		}

		@Transactional
		public void delete(String id) {
			User UserToDelete = new User();
			UserToDelete.setId(id);
			sessionFactory.getCurrentSession().delete(UserToDelete);
		}

		@Transactional
		public User get(String id) {
			String hql = "from User where id=" + "'"+ id +"'";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			@SuppressWarnings("unchecked")
			List<User> listCategory = (List<User>) query.list();
			
			if (listUser != null && !listUser.isEmpty()) {
				return listUser.get(0);
			}
			
			return null;
		}
		
		
		@Transactional
		public User getByName(String name) {
			String hql = "from User where name=" + "'"+ name +"'";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			@SuppressWarnings("unchecked")
			List<User> listUser = (List<User>) query.list();
			
			if (listUser != null && !listUser.isEmpty()) {
				return listUser.get(0);
			}
			
			return null;
		}
		public boolean isValidUser(String id, String name) {
			// TODO Auto-generated method stub
			return false;
		}
//		public boolean saveOrUpdate(UserDetails userDetails) {
//			// TODO Auto-generated method stub
//			return false;
//		}


	}
