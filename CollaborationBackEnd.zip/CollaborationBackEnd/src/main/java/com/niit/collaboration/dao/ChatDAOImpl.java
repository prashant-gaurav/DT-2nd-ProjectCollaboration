package com.niit.collaboration.dao;

public class ChatDAOImpl {

}
