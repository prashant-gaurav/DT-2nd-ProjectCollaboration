package com.niit.collaboration.dao;

public interface ChatDAO {

}
