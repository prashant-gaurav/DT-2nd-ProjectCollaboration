package com.niit.collaboration.dao;

import java.util.List;

import com.niit.collaboration.model.User;

public interface UserDAO {
	
	public List<User> list();

	public User get(String id);
	public User getByName(String name);

	public boolean saveOrUpdate(User user);
	
	//public boolean saveOrUpdate(UserDetails userDetails);

	public void delete(String id);
	
	public boolean isValidUser(String id, String name);


}
