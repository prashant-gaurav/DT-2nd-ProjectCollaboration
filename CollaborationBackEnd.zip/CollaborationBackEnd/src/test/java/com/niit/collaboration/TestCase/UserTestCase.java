package com.niit.collaboration.TestCase;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.UserDAO;
import com.niit.collaboration.model.User;

public class UserTestCase {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.callabration");
		context.refresh();
		
		UserDAO userDAO =(UserDAO) context.getBean("userDAO");
		//System.out.println("success");
		
		User product=(User) context.getBean("user");
		//System.out.println("SUCCESS");
		
		/*user.setId (001);
		user.setUsername(" ");
		user.setPassword("12345");
		user.setEmail("User@outlook.in");
		user.setAddress("CAT002");
		user.setStatus("E");
		
		userDAO.saveOrUpdate(product);
		*/
		//userDAO.delete("PRD003");
		
		//System.out.println(userDAO.getUser("001").getName());
		
}
