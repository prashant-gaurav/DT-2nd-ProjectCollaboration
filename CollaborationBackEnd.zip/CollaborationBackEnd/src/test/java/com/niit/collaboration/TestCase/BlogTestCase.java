package com.niit.collaboration.TestCase;

import static org.junit.Assert.*;

import org.junit.Test;

public class BlogTestCase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
