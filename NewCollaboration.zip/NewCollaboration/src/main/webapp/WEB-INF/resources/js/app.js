angular.module("chatApp", [
  "chatApp.controllers",
  "chatApp.services"
]);

angular.module("chatApp.controllers", []); //[] array of java script
angular.module("chatApp.services", []);